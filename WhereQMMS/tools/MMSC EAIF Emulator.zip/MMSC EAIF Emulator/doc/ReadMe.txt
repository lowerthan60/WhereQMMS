MMSC EAIF Emulator

Corrected:
-file name handling to support all operating systems

